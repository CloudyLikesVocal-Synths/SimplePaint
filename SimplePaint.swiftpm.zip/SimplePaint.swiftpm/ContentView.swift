
import SwiftUI
import UIKit

// MARK: - Data Models

/**
 An enumeration to represent different drawing brush types, each with a default
 thickness and opacity.
 */
enum BrushType: String, CaseIterable {
    case pencil = "Pencil"
    case pen = "Pen"
    case marker = "Marker"
    case watercolor = "Watercolor"
    case paintBrush = "Paint Brush"
    case sprayCan = "Spray Can"
    case clay = "Clay"
    case eraser = "Eraser" // Replaced paint bucket with an eraser
    
    // Returns the default thickness for the brush type
    var thickness: CGFloat {
        switch self {
        case .pencil: return 2.0
        case .pen: return 5.0
        case .marker: return 15.0
        case .watercolor: return 20.0
        case .paintBrush: return 30.0
        case .sprayCan: return 45.0
        case .clay: return 55.0
        case .eraser: return 40.0 // Eraser is a bit thicker by default
        }
    }
    
    // Returns the default opacity for the brush type
    var opacity: CGFloat {
        switch self {
        case .pencil: return 0.7
        case .pen: return 1.0
        case .marker: return 0.6
        case .watercolor: return 0.2
        case .paintBrush: return 1.0
        case .sprayCan: return 0.1
        case .clay: return 1.0
        case .eraser: return 1.0 // Eraser is fully opaque
        }
    }
}

/**
 A struct to hold the properties of a line drawn.
 */
struct Line: Equatable {
    let points: [CGPoint]
    let color: UIColor
    let thickness: CGFloat
    let opacity: CGFloat
    
    // Conforming to Equatable to make it easier to remove lines
    static func == (lhs: Line, rhs: Line) -> Bool {
        return lhs.points == rhs.points &&
               lhs.color == rhs.color &&
               lhs.thickness == rhs.thickness &&
               lhs.opacity == rhs.opacity
    }
}

/**
 A struct to represent a drawing layer, which is a collection of `Line` objects.
 This helps manage multiple drawing surfaces within a single canvas.
 */
struct Layer {
    var lines: [Line] = []
}

/**
 An `ObservableObject` class that holds the state of the drawing.
 It is responsible for managing layers, brush properties, and the drawing process.
 */
class DrawingState: ObservableObject {
    @Published var layers: [Layer]
    @Published var activeLayerIndex: Int = 0
    @Published var currentColor: UIColor = .black
    @Published var currentThickness: CGFloat = 5.0
    @Published var currentOpacity: CGFloat = 1.0
    @Published var currentlyDrawingPoints: [CGPoint]?
    
    init() {
        self.layers = [Layer()]
    }
    
    // Adds a new layer to the drawing.
    func addLayer() {
        layers.append(Layer())
        activeLayerIndex = layers.count - 1
    }
    
    // Adds a new line to the active layer.
    func addLine(_ line: Line) {
        layers[activeLayerIndex].lines.append(line)
    }
    
    // Removes lines from the active layer that are near the given point.
    func removeLinesNear(_ point: CGPoint, withTolerance tolerance: CGFloat) {
        // Create a new array of lines, keeping only the ones that aren't "erased"
        layers[activeLayerIndex].lines.removeAll { line in
            line.points.contains { linePoint in
                return distance(linePoint, point) < tolerance
            }
        }
    }
    
    // Helper function to calculate the distance between two points.
    private func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2))
    }
    
    // Clears the entire drawing by resetting all layers.
    func clearDrawing() {
        layers = [Layer()]
        activeLayerIndex = 0
    }
}

// MARK: - Views

/**
 A `UIView` subclass that handles the core drawing logic using UIKit.
 It draws all layers and the temporary line being drawn by the user.
 */
class DrawingCanvasView: UIView {
    var drawingState: DrawingState
    var activeTool: BrushType
    
    init(drawingState: DrawingState, activeTool: BrushType) {
        self.drawingState = drawingState
        self.activeTool = activeTool
        super.init(frame: .zero)
        self.isMultipleTouchEnabled = false
        self.backgroundColor = .clear
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // Draws all lines from all layers onto the canvas.
    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else { return }
        
        // Draw all lines from all layers
        for layer in drawingState.layers {
            for line in layer.lines {
                context.setStrokeColor(line.color.cgColor.copy(alpha: line.opacity)!)
                context.setLineWidth(line.thickness)
                context.setLineCap(.round)
                context.setLineJoin(.round)
                
                guard let firstPoint = line.points.first else { continue }
                context.beginPath()
                context.move(to: firstPoint)
                
                for point in line.points.dropFirst() {
                    context.addLine(to: point)
                }
                context.strokePath()
            }
        }
        
        // Draw the current line being drawn
        if let currentPoints = drawingState.currentlyDrawingPoints {
            context.setStrokeColor(drawingState.currentColor.cgColor.copy(alpha: drawingState.currentOpacity)!)
            context.setLineWidth(drawingState.currentThickness)
            context.setLineCap(.round)
            context.setLineJoin(.round)
            
            guard let firstPoint = currentPoints.first else { return }
            context.beginPath()
            context.move(to: firstPoint)
            
            for point in currentPoints.dropFirst() {
                context.addLine(to: point)
            }
            context.strokePath()
        }
    }
    
    // Handles touch begin event, starting a new line or erasing.
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: self)
        
        if activeTool == .eraser {
            let tolerance = drawingState.currentThickness / 2
            drawingState.removeLinesNear(point, withTolerance: tolerance)
        } else {
            // Start a new line
            drawingState.currentlyDrawingPoints = [point]
        }
        self.setNeedsDisplay()
    }
    
    // Handles touch move event, adding points to the current line or erasing.
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let point = touch.location(in: self)
        
        if activeTool == .eraser {
            let tolerance = drawingState.currentThickness / 2
            drawingState.removeLinesNear(point, withTolerance: tolerance)
        } else {
            guard var currentPoints = drawingState.currentlyDrawingPoints else { return }
            currentPoints.append(point)
            drawingState.currentlyDrawingPoints = currentPoints
        }
        self.setNeedsDisplay()
    }
    
    // Handles touch end event, completing a line.
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let newPoint = touch.location(in: self)
        
        if activeTool != .eraser {
            guard var finalPoints = drawingState.currentlyDrawingPoints else { return }
            finalPoints.append(newPoint)
            
            let finalLine = Line(points: finalPoints, color: drawingState.currentColor, thickness: drawingState.currentThickness, opacity: drawingState.currentOpacity)
            drawingState.addLine(finalLine)
        }
        
        // This is the fix: always reset the drawing points after a touch ends.
        drawingState.currentlyDrawingPoints = nil
        
        self.setNeedsDisplay()
    }
}

/**
 A SwiftUI wrapper for `DrawingCanvasView` to make it usable in a SwiftUI view hierarchy.
 */
struct DrawingCanvasViewRepresentable: UIViewRepresentable {
    @ObservedObject var drawingState: DrawingState
    var activeTool: BrushType
    
    func makeUIView(context: Context) -> DrawingCanvasView {
        let view = DrawingCanvasView(drawingState: drawingState, activeTool: activeTool)
        return view
    }
    
    func updateUIView(_ uiView: DrawingCanvasView, context: Context) {
        uiView.drawingState = drawingState
        uiView.activeTool = activeTool
        uiView.setNeedsDisplay()
    }
}

// MARK: - Save and Share Helper

/**
 A `UIViewControllerRepresentable` to present the native share sheet.
 */
struct ShareSheetView: UIViewControllerRepresentable {
    let activityItems: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
        return controller
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - Main App View

/**
 The main `ContentView` that presents the drawing canvas and user interface controls.
 */
struct ContentView: View {
    @StateObject private var drawingState = DrawingState()
    @State private var activeTool: BrushType = .pen // State to track the active tool
    @State private var showingShareSheet = false // State to control the share sheet

    let brushTools = BrushType.allCases
    
    // State for the color picker
    @State private var selectedColor: Color = .black
    
    // A view to hold the canvas for rendering
    var canvasView: some View {
        DrawingCanvasViewRepresentable(drawingState: drawingState, activeTool: activeTool)
            .edgesIgnoringSafeArea(.all)
            .background(Color.white)
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            // Main drawing canvas
            canvasView
            
            // Top Controls (Layers)
            VStack(alignment: .leading) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(0..<drawingState.layers.count, id: \.self) { index in
                            Button("Layer \(index + 1)") {
                                drawingState.activeLayerIndex = index
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 8)
                            .background(drawingState.activeLayerIndex == index ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                            .cornerRadius(20)
                            .foregroundColor(drawingState.activeLayerIndex == index ? .white : .primary)
                        }
                        
                        Button("+") {
                            drawingState.addLayer()
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(Color.green.opacity(0.8))
                        .cornerRadius(20)
                        .foregroundColor(.white)
                    }
                    .padding(.horizontal)
                }
                Spacer()
            }
            .padding(.top, 20)
            
            // Bottom Controls
            VStack {
                // Brush Tools ScrollView
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(brushTools, id: \.self) { tool in
                            Button(action: {
                                activeTool = tool
                                
                                // Reset the drawing points to fix the bug
                                drawingState.currentlyDrawingPoints = nil
                                
                                drawingState.currentThickness = tool.thickness
                                drawingState.currentOpacity = tool.opacity
                                
                                // Only change color if it's the eraser. Otherwise, the ColorPicker will handle it.
                                if tool == .eraser {
                                    drawingState.currentColor = UIColor(Color.white)
                                }
                            }) {
                                Text(tool.rawValue)
                                    .font(.system(size: 14, weight: .semibold))
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 8)
                                    .background(activeTool == tool ? Color.blue.opacity(0.8) : Color.gray.opacity(0.2))
                                    .cornerRadius(20)
                                    .foregroundColor(activeTool == tool ? .white : .primary)
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                
                // Color Picker
                VStack(spacing: 8) {
                    Text("Color")
                        .font(.caption)
                    
                    ColorPicker("Select Color", selection: $selectedColor)
                        .labelsHidden()
                        .frame(maxWidth: .infinity)
                        .onChange(of: selectedColor) { newColor in
                            // This is the correct place to update the drawing color for all non-eraser tools.
                            drawingState.currentColor = UIColor(newColor)
                        }
                }
                .padding(.horizontal)

                // Sliders
                VStack(spacing: 16) {
                    HStack(spacing: 12) {
                        Text("Thickness").font(.caption)
                        Slider(value: $drawingState.currentThickness, in: 1...60)
                            .tint(.blue)
                        Text(String(format: "%.0f", drawingState.currentThickness)).font(.caption)
                    }
                    
                    HStack(spacing: 12) {
                        Text("Opacity").font(.caption)
                        Slider(value: $drawingState.currentOpacity, in: 0.1...1.0)
                            .tint(.blue)
                        Text(String(format: "%.2f", drawingState.currentOpacity)).font(.caption)
                    }
                }
                .padding()
                
                // Clear/Save Buttons
                HStack(spacing: 12) {
                    Button("Clear") {
                        drawingState.clearDrawing()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    
                    Button("Save") {
                        // Create a UIImage from the canvas data and present a share sheet
                        let imageToSave = renderDrawingToImage()
                        if let image = imageToSave {
                            showingShareSheet = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    
                    Spacer()
                }
                .padding()
            }
            .padding()
            .background(Color.white.opacity(0.8).cornerRadius(25).shadow(radius: 10))
            .padding(.horizontal)
            .padding(.bottom, 20)
            
            // Share sheet view
            if showingShareSheet, let imageToShare = renderDrawingToImage() {
                ShareSheetView(activityItems: [imageToShare])
                    .onDisappear {
                        showingShareSheet = false
                    }
            }
        }
    }
    
    // Function to render the drawing state to a UIImage
    func renderDrawingToImage() -> UIImage? {
        let drawingCanvas = DrawingCanvasView(drawingState: drawingState, activeTool: activeTool)
        
        let size = UIScreen.main.bounds.size
        let renderer = UIGraphicsImageRenderer(size: size)
        
        return renderer.image { context in
            // Set a background color for the image
            UIColor.white.setFill()
            UIRectFill(CGRect(origin: .zero, size: size))
            
            // Draw all lines from all layers
            for layer in drawingState.layers {
                for line in layer.lines {
                    context.cgContext.setStrokeColor(line.color.cgColor.copy(alpha: line.opacity)!)
                    context.cgContext.setLineWidth(line.thickness)
                    context.cgContext.setLineCap(.round)
                    context.cgContext.setLineJoin(.round)
                    
                    guard let firstPoint = line.points.first else { continue }
                    context.cgContext.beginPath()
                    context.cgContext.move(to: firstPoint)
                    
                    for point in line.points.dropFirst() {
                        context.cgContext.addLine(to: point)
                    }
                    context.cgContext.strokePath()
                }
            }
        }
    }
}

// MARK: - App Entry Point

struct DrawingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

